public class Variables {

    // comment

    // main method or main function
    public static void main(String[] args) {
        // variables -> x = 100 , y = 200 , x+y = 300
        // datatypes -> primitive , non-primitive -> String
        // byte    -> whole numbers -> 1 byte  -> -128 to 127
        // short   -> whole numbers -> 2 bytes -> -32k to 32k
        // integer -> whole numbers -> 4 bytes -> -2*10(9) to 2*10(9)
        // long    -> whole numbers -> 8 bytes -> -2*10(63) to 2*10(63)
        // float   -> decimal numbers -> 4 bytes -> 6 decimal digits
        // double  -> decimal numbers -> 8 bytes -> 16 decimal digits
        // boolean
        // char
        // String




//        float x = 10002.000110f;
//
//        System.out.println(x);
//        System.out.println(x);


//        boolean b = false;

//        char c = '@';
        String s = "skfjsh sfdshjdfjksf";
        System.out.println(s);


    }
}

// heap , stack