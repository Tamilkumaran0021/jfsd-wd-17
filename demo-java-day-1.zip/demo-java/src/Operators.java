public class Operators {
    public static void main(String[] args) {
        // operators -> + - * / %(module) == != > < >= <= >> << ++ --

//        int x = 8;

//        System.out.println(x >> 1);


        int x = 10;
//        x = x + 1;
//        x++;
//        System.out.println(++x);
//        System.out.println(x++);
//        System.out.println(x);


//        x--;
//        System.out.println(x);

//        x = x + 2;
//        x += 2;

        x -= 2;
        x *= 2;

        System.out.println(x);


    }
}
